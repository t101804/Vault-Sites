# Someone's Idol

## ATTACHMENTS

poster.zip

## FLAG

```console
LKS2024Malang{Y0u_goT_M3_4_G0Od}
```

## Description

Why does anyone still hold this poster dearly, it's 2024th for goodness sake!

## Difficulty

easy

## Hints

* Something suspicious about this file, if only i can get the original file...

## Tags

forensic

## Notes
>
> Intentionally left empty
