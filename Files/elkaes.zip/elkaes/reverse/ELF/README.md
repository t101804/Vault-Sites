# ELF

---

## Flag

```console
LKS2024Malang{tH1s_Fl4g_Ch3ckEr_sUr3_1S_W3iRd}
```

## Description

Just our litle flag chacker, submit LKS2024MALANG{real_flag}

## ATTACHMENTS

chall.zip

## Difficulty

easy

## Hints

*

## Tags

debugging reverse-engineering

## Notes

*
