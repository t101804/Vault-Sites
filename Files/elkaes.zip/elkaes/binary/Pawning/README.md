# Pawning

---

## Flag

```
LKS2024Malang{l3tS_Pwn_d4_wOrlD_l0L}
```

## Description

Can you Pawn this one?
nc IP 10012

## Difficulty

easy-medium

## Hints

* Googling 'Vuln buffer overflow'

## Tags

overflow

## Deployment

* Install docker engine>=19.03.12 and docker-compose>=1.26.2.

* Run the container using:

    ```
    docker-compose up --build --detach
    ```

## ATTACHMENTS

release/chal.zip

## Notes

*
