#! /bin/bash
cd /home/ctf && ./pawning
