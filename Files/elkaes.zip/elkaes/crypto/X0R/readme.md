# Xor

Author: `Hazbiy`

## ATTACHMENTS

encrypted-img

## FLAG

```
LKS2024Malang{yOu_d3crypt_m3_Huh}
```

## Description

Today i visit a museum. It was an animal museum
While it was fun, i see some gold bug with strange name displayed
It says "3‡0†2?3", what does that even mean?

## Difficulty

easy

## Hints
>
> Intentionally left empty

## Tags

cryptography

## Notes
>
> Intentionally left empty
