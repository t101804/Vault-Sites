# Secret

---

## Flag

```console
LKS2024Malang{w3b_Not3S_i5_R3Al}
```

## Description

Struktur challenge ini dibuat menggunakan standard tool berikut <https://github.com/CTFd/ctfcli>.

Untuk informasi challenge bisa di cek di dalam file `challenge.yml`.

IP:15907

## Difficulty

easy-medium

## Hints

*

## Tags

web-hacking injection

## Deployment

* Install docker engine>=19.03.12 and docker-compose>=1.26.2.
* Run the container using:

    ```console
    docker-compose up --build --detach
    ```

## Notes

*
