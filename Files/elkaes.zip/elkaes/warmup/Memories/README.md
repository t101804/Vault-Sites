# Memories

---

## Flag

```console
LKS2024Malang{P3maNasa4n_DUlu_5ir_Buat_B3sok_W4ktu_P3nyi5ih4n_G00D_Luck_51r!!!}
```

## Description

Just a little warm up

## Difficulty

easy

## Hints

*

## Tags

`warmup`

## Attachment

public/chall.zip

## Deployment

Just run command:

```console
docker-compose up --build -d
```

Or

```console
docker compose up --build -d
```

## Notes

*
