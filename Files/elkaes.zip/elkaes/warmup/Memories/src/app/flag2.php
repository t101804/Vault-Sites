<?php

function your_flag() {
    echo "<p>Buat_B3sok_W4ktu_</p>";
    echo "<br>";
    echo "<!--  /L4sszZt-P4G3eEE-KvBzzD290XhhhHoLpAjg7UY1nd0SpK4cC0eRL6m1DssV.php -->";
}
