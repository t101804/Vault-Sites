<?php

function your_flag() {
    echo "<p>LKS2024Malang{P3maNasa4n_DUlu_5ir_</p>";
    echo "<br>";
    echo "<!-- /Next-P493eEE-0lpppkas9942177ThyfR724SMz6zRRea524SkCWq65SSduLm.php -->";
}
