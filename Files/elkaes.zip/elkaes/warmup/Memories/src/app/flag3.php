<?php

function your_flag() {
    echo "<p>P3nyi5ih4n_G00D_Luck_51r!!!}</p>";
    echo "<br>";
}
