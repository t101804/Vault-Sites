# Kode Nuklir

## FLAG

```console
LKS2024Malang{B1g_th4nKs_fOr_K3eP1nG_My_F1L3s}
```

## Description

In the past, i have a BFF. so close that Joe (not real name) gave me his secret crazy collection to me and he said "whatever happens, whatever the circumstance, if the worst comes to the worst, take a very good care of this amazing collection, and purge everything." Now he just get married, he said "i'm no longer need the data i entrusted to you". it's really nice to hear, but now I'm curiousabout the data that he loves so dearly. I know curiousity kill the cats, but still...

```bash
lks2024@<HOST> -p <10101> 
```

## Difficulty

medium

## Hints

> Do you know about "we will rock you" song? He said if he ever forget what he hold dearly, he always singing it aloud
> Do you know about "nc"

## Tags

forensic

## Deployment

- Change the nothing-special.mp4.dat content to platform ip address
- Change the description Host to platform ip address
- Run the container using:

```bash
    docker-compose up --build --detach
```

## Notes

> Intentionally left empty

## Attachment

> id_rsa.zip
